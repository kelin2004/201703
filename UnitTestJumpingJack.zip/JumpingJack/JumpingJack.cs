﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JumpingJack
{
    public class JumpingJack
    {
        /*******************************************************************
         * Jumping Jack is standing at the bottom of a long flight of stairs.
         * The bottom of the stairs has number 0,
         * and the steps are numbered sequentially from 1 to infinity. 
         * Jack will perform N consecutively numbered actions.
         * For each action X, Jack can either jump exactly X steps, 
         * or pass and stay where he was before. 
         * So if Jack is standing on step Y when it is time to perform action X, 
         * then he will end that turn either on step Y or on step Y+X.
         * If X < N then action X+1 is performed next.
         * For example, if N= 3, Jack will make three consecutive choices: 
         * whether or not to jump 1 step upwards, 
         * 2 steps upwards, and then 3 steps upwards.
         * There is exactly one step, numbered K, 
         * which is missing.Jack cannot jump onto this step.
         * You are given the integers N and K. 
         * Compute and return the number of the topmost step that can be reached by Jack. 
         ************************************************************************************/
        public int maxstep(int N, int K)
        {
            int intRst = 0;
            int intActionN = -1;

            if (N < 1 || N > 2000)
            {
                Console.WriteLine("Error: N is not between 1 and 2000 inclusive");
                return intRst;
            }
            if (K < 1 || K > 4000000)
            {
                Console.WriteLine("Error: K is not between 1 and 4000000 inclusive");
                return intRst;
            }

            intRst = (1 + N) * N / 2;
            if (K <= intRst)
            {
                intActionN = findNthAction(K);
                intRst = (intActionN == -1) ? intRst : intRst - intActionN;
            }

            return intRst;
        }
        //Given step number, find after N consecutive actions, 
        //Jack stop at given step
        //if not exist such n return -1, 
        //else return n

        public int findNthAction(int intStepNum)
        {
            int intRst = -1;
            //total steps after n action are 1 + 2 + ..+ n = (1+n)*n/2
            //n is biggest int less than squart root of 2*total stemps
            int intSqrt = (int)Math.Floor(Math.Sqrt(2*intStepNum));
            if((intSqrt+1)*intSqrt/2 == intStepNum)
            { intRst = intSqrt; } 
            return intRst;
        }

    }
}
