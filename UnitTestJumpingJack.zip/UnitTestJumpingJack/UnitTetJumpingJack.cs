﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace JumpingJack
{
    [TestClass]
    public class UnitTetJumpingJack
    {
        [TestMethod]
        public void TestfindNthAction_1()
        {
            int intStepNum = 1;
            JumpingJack objJack = new JumpingJack();
            int n = objJack.findNthAction(intStepNum);
            Assert.IsTrue(n==1);
        }

        [TestMethod]
        public void TestfindNthAction_2000()
        {
            int intStepNum = 2001000;
            JumpingJack objJack = new JumpingJack();
            int n = objJack.findNthAction(intStepNum);
            Assert.IsTrue(n == 2000);
        }

        [TestMethod]
        public void TestfindNthAction_6()
        {
            int intStepNum = 6;
            JumpingJack objJack = new JumpingJack();
            int n = objJack.findNthAction(intStepNum);
            Assert.IsTrue(n ==3);
        }

        [TestMethod]
        public void TestfindNthAction_notExit()
        {
            int intStepNum = 8;
            JumpingJack objJack = new JumpingJack();
            int n = objJack.findNthAction(intStepNum);
            Assert.IsTrue(n == -1);
        }

        [TestMethod]
        public void TestMaxStep_N_invalid1()
        {
            int n = 2001;
            int k = 1;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 0);
        }

        [TestMethod]
        public void TestMaxStep_N_invalid2()
        {
            int n = 0;
            int k = 1;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 0);
        }

        [TestMethod]
        public void TestMaxStep_K_invalid2()
        {
            int n = 1;
            int k = 0;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 0);
        }

        [TestMethod]
        public void TestMaxStep_N1_K1()
        {
            int n = 1;
            int k = 1;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 0);
        }

        [TestMethod]
        public void TestMaxStep_KisLastStopStep()
        {
            int n = 2000;
            int k = 2001000;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 1999000);
        }
        [TestMethod]
        public void TestMaxStep_KHigherthenMaxStep()
        {
            int n = 3;
            int k = 18;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 6);
        }

        [TestMethod]
        public void TestMaxStep_KWinthMaxStepButNotAStopStep()
        {
            int n = 3;
            int k = 4;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 6);
        }
        [TestMethod]
        public void TestMaxStep_KWinthMaxStepIsAStopStep()
        {
            int n = 3;
            int k = 3;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 4);
        }
        [TestMethod]
        public void TestMaxStep_Sample1()
        {
            int n = 2;
            int k = 2;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 3);
        }
        [TestMethod]
        public void TestMaxStep_Sample2()
        {
            int n = 2;
            int k = 1;
            JumpingJack objJack = new JumpingJack();
            int intMaxStep = objJack.maxstep(n, k);
            Assert.IsTrue(intMaxStep == 2);
        }
    }
}
