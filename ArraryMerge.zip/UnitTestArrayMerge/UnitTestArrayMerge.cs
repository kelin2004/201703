﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ArrayMerge
{
    [TestClass]
    public class UnitTestArrayMerge
    {
        [TestMethod]
        public void TestFirstIsNull()
        {
            int[] arrSorted1 = null;
            int[] arrSorted2 = new int[4];
            arrSorted2[0] = 2;
            arrSorted2[1] = 2;
            int intCount = 2;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[4] { 2, 2, 0, 0 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }

        [TestMethod]
        public void TestSecondIsNull()
        {
            int[] arrSorted1 = new int[2];
            int[] arrSorted2 = null;
            int intCount = 2;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            Assert.IsNull(arrSorted2);
        }

        [TestMethod]
        public void TestFirstNoEnoughElements()
        {
            int[] arrSorted1 = new int[1] { 1 };
            int[] arrSorted2 = new int[4];
            arrSorted2[0] = 2;
            arrSorted2[1] = 2;
            int intCount = 2;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[4] { 2, 2, 0, 0 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }

        [TestMethod]
        public void TestSecondNoEnoughElements()
        {
            int[] arrSorted1 = new int[1] { 1 };
            int[] arrSorted2 = new int[1];
            arrSorted2[0] = 2;
            int intCount = 2;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[1] { 2 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }
        [TestMethod]
        public void TestAllSecondElementsLessThanFirst()
        {
            int[] arrSorted1 = new int[3] { 2, 2, 2 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 1;
            arrSorted2[1] = 1;
            arrSorted2[2] = 1;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 1, 1, 1, 2, 2, 2 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }
        [TestMethod]
        public void TestSomeSecondElementsLessThanFirst()
        {
            int[] arrSorted1 = new int[3] { 2, 4, 5 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 1;
            arrSorted2[1] = 2;
            arrSorted2[2] = 3;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 1, 2, 2, 3, 4, 5 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }
        [TestMethod]
        public void TestSecondElementsSameFirst()
        {
            int[] arrSorted1 = new int[3] { 1, 2, 3 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 1;
            arrSorted2[1] = 2;
            arrSorted2[2] = 3;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 1, 1, 2, 2, 3, 3 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }
        [TestMethod]
        public void TestSomeSecondElementsBiggerThanFirstButSmallFirstMax()
        {
            int[] arrSorted1 = new int[3] { 1, 5, 6 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 2;
            arrSorted2[1] = 3;
            arrSorted2[2] = 4;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 1, 2, 3, 4, 5, 6 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }

        [TestMethod]
        public void TestAllSecondElementsHasBiggerRangeThanFirst()
        {
            int[] arrSorted1 = new int[3] { 4, 5, 6 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 2;
            arrSorted2[1] = 7;
            arrSorted2[2] = 8;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 2, 4, 5, 6, 7, 8 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }

        [TestMethod]
        public void TestAllSecondElementsBiggerThanFirst()
        {
            int[] arrSorted1 = new int[3] { 1, 2, 3 };
            int[] arrSorted2 = new int[6];
            arrSorted2[0] = 4;
            arrSorted2[1] = 5;
            arrSorted2[2] = 6;

            int intCount = 3;
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            int[] arrExpected = new int[6] { 1, 2, 3, 4, 5, 6 };
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }

        [TestMethod]
        public void TestRandomElements()
        {
            int intCount = 15;
            int[] arrSorted1 = new int[intCount];
            int[] arrTemp = new int[intCount];
            int[] arrSorted2 = new int[2* intCount];
            int[] arrExpected = new int[2 * intCount];
            Random objRandom = new Random(DateTime.Now.Second);
            for (int i = 0; i < intCount; i++) {
                arrSorted1[i] = objRandom.Next(1, 1000);
                arrTemp[i] = objRandom.Next(1, 1000);
                arrExpected[i] = arrSorted1[i];
                arrExpected[intCount + i] = arrTemp[i];
            }

            System.Array.Sort(arrSorted1);
            System.Array.Sort(arrTemp);
            arrTemp.CopyTo(arrSorted2, 0);
            System.Array.Sort(arrExpected);
            ArrayUtility.mergeArray(arrSorted1, arrSorted2, intCount);
            Assert.IsTrue(Enumerable.SequenceEqual(arrSorted2, arrExpected));
        }



    }
}
