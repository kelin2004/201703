﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayMerge
{
    public class ArrayUtility
    {/****************************************************
        Takes in two sorted arrays a and b as parameters. 
        The first array has M elements in it. 
        The second one also has M elements, but it's capacity is 2M. 
        The function mergeArrays takes both the arrays as parameters along with M.
        Merge the first array into the second array such that the resulting array is sorted.
        **************************************************/
        public static void mergeArray(int[] a, int[] b, int M)
        {
            if (null == a || a.Length < M) {
                Console.WriteLine("First array is invalid.");
                return;
            }
            if (null == b || b.Length < M)
            {
                Console.WriteLine("Second array is invalid.");
                return;
            }
            if (b.Length < 2*M)
            {
                Console.WriteLine("Second array's capacity is not right.");
                return;
            }

            int i = M - 1;
            int j = M - 1;
            int k = M + M - 1;

            while (i >= 0 && j >= 0)
            {
                b[k--] = (a[i] > b[j]) ? a[i--] : b[j--]; 
            }
            while (i >= 0)
            {
                b[k--] = a[i--];
            }

            return;
        }
    }
}
