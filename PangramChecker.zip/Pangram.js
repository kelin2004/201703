/***********************************************************************
Pangrams are sentences constructed by using every letter of the alphabet at least once.
Check whether a given string is pangram
************************************************************************/
var isPangram = function (sentence) {
    var AllLetters = 'abcdefghijklmnopqrstuvwxyz';
    if (sentence && sentence.length == 0)
        return false;

    if (sentence.length > 103)
    {
        //do something.
    }
    var temp = sentence.toLowerCase();
    for (i = 0; i < temp.length && AllLetters.length > 0; i++) {
        AllLetters = AllLetters.replace(temp[i], "");
    }
    if (AllLetters.length == 0)
        return true;

    return false;
}

var isPangram2 = function (sentence) {
    var AllLetters = 'abcdefghijklmnopqrstuvwxyz';
    if (sentence && sentence.length == 0)
        return false;

    if (sentence.length > 103)
    {
        //do something.
    }
    var temp = sentence.toLowerCase();
    for (i = 0; i < temp.length && AllLetters.length > 0; i++) {
        AllLetters = AllLetters.replace(temp[i], "");
    }

    return AllLetters;
}

