﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationDistribute
{
    public class City
    {
        // number of clinic in the city
        public int NumOfClinic{ get; set; }
        // how many people in the city
        public int Population { get; set; }
        // number of vaccination in each clinic
        public int VaccinateLoad { get; set; }

        public City(int intPopulation)
        {
            NumOfClinic = 1;
            Population = intPopulation;
            calVaccLoad();
        }

        private void calVaccLoad()
        {
            // 2.5 number of vaccination will save as 3 
            this.VaccinateLoad = (int)Math.Ceiling((1.0 * this.Population) / this.NumOfClinic);
            return;
        }

        // add one clinic to the city. recalculate number of vaccination in 
        //each clinic
        public void increaseNumOfClinic()
        {
            this.NumOfClinic++;
            calVaccLoad();
            return;
        }
    }
}
