﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationDistribute
{
    public class VaccinationHandler
    {
        public int NumOfCity;
        public int NumOfClinic;
        public List<City> CityList;

        public VaccinationHandler()
        {
            NumOfCity = 1;
            NumOfClinic = 1;
            CityList = new List<City>();
            CityList.Add(new City(0));
        }

        public VaccinationHandler(int intCityN, int intClinicN, int[] arrPopulation) {
            //valid number of city input 1 ≤ N ≤ 500,000
            if (intCityN < 1 || intCityN > 500000){
                //do something
                new VaccinationHandler();
                return;
            }

            //valid number of clinic input N ≤ B ≤ 2,000,000
            if (intClinicN < intCityN || intClinicN > 2000000){
                //do something
                new VaccinationHandler();
                return;
            }

            // valid population information of all city are provided
            if (arrPopulation.Length < intCityN)
            {
                //do something
                new VaccinationHandler();
                return;
            }

            ////valid population input 1 ≤ ai ≤ 5,000,000
            ////comment out because this step need go through every element in list. 
            //for (int intIndex=0; intIndex < arrPopulation.Length; intIndex++)
            //{
            //    if (arrPopulation[intIndex] < 1 || arrPopulation[intIndex] > 5000000) {
            //        //do something
            //        new VaccinationHandler();
            //        return;
            //    }
            //}

            NumOfCity = intCityN;
            NumOfClinic = intClinicN;
            CityList = new List<City>();
            City objC;
            if (null == arrPopulation || arrPopulation.Length == 0)
                return;
            for (int i = 0; i < arrPopulation.Length; i++) {
                objC = new City(arrPopulation[i]);
                CityList.Add(objC);
            }
        }
        /*********************************************************************************
         * The World Health Organization (WHO) wants to establish a total of B vaccination 
         * clinics across N cities to immunization people against fatal diseases. 
         * Every city must have at least 1 clinic, and a clinic can only vaccinate people 
         * in the same city where they live. The goal is to minimize the number of vaccination 
         * kits needed in the largest clinic.
         *********************************************************************************/
        public int findMinNumOfkits()
        {
            sortCityList();

            //allocate (NumOfClinic - NumOfCity) clinic.
            //city has biggest vaccination in one clinic will get 1 additional clinic
            //sort list after information updated
            for (int intIndex = 0; intIndex < (NumOfClinic - NumOfCity); intIndex++)
            {
                CityList[NumOfCity - 1].increaseNumOfClinic();
                sortCityList();
            }

            //last one has biggest number of vaccination in one clinic
            return CityList[NumOfCity - 1].VaccinateLoad;
        }

        private void sortCityList()
        {
            CityList = CityList.OrderBy(o => o.VaccinateLoad).ToList();
        }
    }
}
