﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationDistribute
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
