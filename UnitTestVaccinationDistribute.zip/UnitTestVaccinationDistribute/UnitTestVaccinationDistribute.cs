﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VaccinationDistribute
{
    [TestClass]
    public class UnitTestVaccinationDistribute
    {
        [TestMethod]
        public void TestCreateCity()
        {
            City objCity = new City(2000);

            Assert.IsTrue(objCity.NumOfClinic == 1 && objCity.Population == 2000 && objCity.VaccinateLoad == 2000.0);
        }


        [TestMethod]
        public void TestincreaseNumOfClinic()
        {
            City objCity = new City(201);
            objCity.increaseNumOfClinic();

            Assert.IsTrue(objCity.VaccinateLoad == 101);
        }

        [TestMethod]
        public void TestCreateVaccinationHandler()
        {
            int intCity = 1;
            int intClinic = 2;
            int[] arrPopulation = new int[] { 2000};
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);

            Assert.IsTrue(objHandler.NumOfCity == 1 && objHandler.NumOfClinic == 2 && objHandler.CityList.Count == 1);
        }

        [TestMethod]
        public void TestfindMaxNumOfPeople()
        {
            int intCity = 2;
            int intClinic = 7;
            int[] arrPopulation = new int[] { 2000, 5000 };
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);
            int intRst = objHandler.findMinNumOfkits();
            Assert.IsTrue(intRst == 1000);
        }

        [TestMethod]
        public void TestfindMaxNumOfPeople2()
        {
            int intCity = 1;
            int intClinic = 2;
            int[] arrPopulation = new int[] { 10000 };
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);
            int intRst = objHandler.findMinNumOfkits();
            Assert.IsTrue(intRst == 5000);
        }

        [TestMethod]
        public void TestfindMaxNumOfPeople3()
        {
            int intCity = 3;
            int intClinic = 5;
            int[] arrPopulation = new int[] { 10000, 10000, 10000 };
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);
            int intRst = objHandler.findMinNumOfkits();
            Assert.IsTrue(intRst == 10000);
        }

        [TestMethod]
        public void TestfindMaxNumOfPeople4()
        {
            int intCity = 3;
            int intClinic = 15;
            int[] arrPopulation = new int[] { 5000000, 5000000, 5000000 };
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);
            int intRst = objHandler.findMinNumOfkits();
            Assert.IsTrue(intRst == 1000000);
        }
                [TestMethod]
        public void TestfindMaxNumOfPeople5()
        {
            int intCity = 1;
            int intClinic = 2000000;
            int[] arrPopulation = new int[] { 5000000};
            VaccinationHandler objHandler = new VaccinationHandler(intCity, intClinic, arrPopulation);
            int intRst = objHandler.findMinNumOfkits();
            Assert.IsTrue(intRst ==(int)Math.Ceiling(5000000 * 1.0 / 2000000));
        }



    }
}
